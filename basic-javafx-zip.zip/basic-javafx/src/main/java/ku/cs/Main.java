package ku.cs;
import ku.cs.basicjavafx.HelloApplication;
public class Main {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}
